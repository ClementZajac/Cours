int main();
int genererRandom();
void partie1Exo1();
void partie1Exo2();
void partie1Exo3();
double remplirSansDoublons(double* tab, int max);
void afficherLectureEcriture(); 
void afficherLecture();
void afficherEcriture();


 