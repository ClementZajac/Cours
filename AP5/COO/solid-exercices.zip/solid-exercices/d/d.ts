import axios from "axios";

class HttpClient {
  async get(url: string) {
    return await axios.get(url);
  }

  async post(url: string, payload: any) {
    return await axios.post(url, payload);
  }
}

const http = new HttpClient();

class ProductService {
  async getProducts() {
    return await http.get("/products");
  }

  async createProduct(product: any) {
    return await http.post("/products", product);
  }
}
