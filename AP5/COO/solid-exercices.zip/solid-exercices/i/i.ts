interface Shape {
  getArea(): number;

  getVolume(): number;
}

class Cylinder implements Shape {
  height = 0;

  radius = 0;

  getVolume(): number {
    return Math.PI * Math.pow(this.radius, 2) * this.height;
  }

  getArea(): number {
    return 2 * Math.PI * this.radius * (this.height + this.radius);
  }
}

class Square implements Shape {
  side = 0;

  getVolume(): number {
    throw new Error("Methods not implemented");
  }

  getArea(): number {
    return Math.pow(this.side, 2);
  }
}
